#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.vst3"
rm -rf "$HOME/.vst3/earStep.vst3"
cp -a "$ROOT/.vst3/earStep.vst3" "$HOME/.vst3/earStep.vst3"
if [[ -f "$ROOT/bin/earStep" ]]; then
  mkdir -p "$HOME/.local/bin"
  cp "$ROOT/bin/earStep" "$HOME/.local/bin/earStep"
fi
echo "Installed earStep VST3 to $HOME/.vst3/earStep.vst3"
